package core.DS.timetracker;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class CTaskLimitedTime extends CTaskDecorator implements PropertyChangeListener {

    public CTaskLimitedTime(CTask task, long maxTime) {
        super(task);
        m_maxTime = maxTime;
        CClock.getInstance().addPropertyChangeListener(this);
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if(evt.getPropertyName().equals("Counter")) {// For the case of many Observables, ask if it is the Counter
            this.m_task.m_currentTime = (long) evt.getNewValue(); // On event set m_currentTime to Clock's counter passed as NewValue
            if (this.m_task.getCurrentTime() - this.m_task.m_startTime > m_maxTime) {
                this.trackTaskStop();
            }
        }
    }

    @Override
    public void trackTaskStart() {
        super.trackTaskStart();
        this.m_task.setStartTime( CClock.getInstance().getTime() );
    }

    @Override
    public void trackTaskStop() {
        super.trackTaskStop();
        CClock.getInstance().removePropertyChangeListener(this);
    }

    /* Properties */
    private long m_maxTime;
}
