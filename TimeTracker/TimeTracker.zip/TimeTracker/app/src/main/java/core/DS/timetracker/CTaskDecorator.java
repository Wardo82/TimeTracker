package core.DS.timetracker;

public class CTaskDecorator extends CTask {

    public CTaskDecorator(CTask task) {
        this.m_task =  task;
        m_startTime = task.getStartTime();
    }

    @Override
    public String getName() {
        return this.m_task.getName();
    }

    @Override
    public long getStartTime() {
        return this.m_task.getStartTime();
    }

    @Override
    public void trackTaskStart() {
        this.m_task.trackTaskStart();
    }

    @Override
    public void trackTaskStop() {
        this.m_task.trackTaskStop();
    }

    @Override
    public long getCurrentTime() {
        return this.m_task.getCurrentTime();
    }

    @Override
    public long getTotalTime() {
        return this.m_task.getTotalTime();
    }


    protected CTask m_task;
}
