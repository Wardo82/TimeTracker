package core.DS.timetracker;

public class CTaskBasic extends CTask {

    public CTaskBasic(String name, String description) { super(name, description); }
}
